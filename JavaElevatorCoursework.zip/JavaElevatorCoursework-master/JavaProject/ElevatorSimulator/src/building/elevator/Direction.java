package building.elevator;

public enum Direction {
	UP, DOWN, NO_DIRECTION;

}
