package building;

public class Building {

}
