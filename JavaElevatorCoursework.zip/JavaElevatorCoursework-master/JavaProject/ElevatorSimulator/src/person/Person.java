package person;

import building.Floor;

public abstract class Person {
	
	float currentProbability;
	Floor currentFloor;
	int capacityUsage;
	
	public abstract void setProbability();
	
	public abstract void getProbability();
	
	public abstract void setDestinationFloor();
	
	public abstract void getFloor();
	
	public abstract void tick();
	
	public abstract void setCapacity();
	
	public abstract int getCapacity();

}
