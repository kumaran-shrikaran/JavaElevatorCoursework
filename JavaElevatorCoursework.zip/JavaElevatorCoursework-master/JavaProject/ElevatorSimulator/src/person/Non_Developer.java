package person;

public class Non_Developer extends Employee {

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setProbability() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getProbability() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDestinationFloor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getFloor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setCapacity() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getCapacity() {
		// TODO Auto-generated method stub
		return 0;
	}

}
