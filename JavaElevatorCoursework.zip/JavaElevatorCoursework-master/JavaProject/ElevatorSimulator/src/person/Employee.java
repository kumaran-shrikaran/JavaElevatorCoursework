package person;

public abstract class Employee extends Person {
	
	public abstract void tick();

}
